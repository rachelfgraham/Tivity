document.getElementById("button").addEventListener('click', onClick);

function onClick() {  
  document.getElementById("body").style.width = "500px";
  document.getElementById("body").style.height = "500px";
  document.getElementById("hooray").style.display = "block";
}